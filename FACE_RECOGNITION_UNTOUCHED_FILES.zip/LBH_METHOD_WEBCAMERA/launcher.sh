cd /
cd home
cd pi
cd BAK
cd LBH_METHOD_WEBCAMERA/
sudo python main.py
cd /
